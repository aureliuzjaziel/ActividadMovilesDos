import { StyleSheet, Text, TextInput, TouchableOpacity, View, Image, Alert } from 'react-native'
import React, { useEffect, useState } from 'react'

export default function CalculoScreen() {
    /*
    verificar si el usuario es mayor de edad, de ser asi calcular el salario anual en base al salario ingresado
    --agregar el decimo tercer (+475)  y cuarto salario (salario completo) sueldo de salario anual
    */

    const [nombre, setnombre] = useState("")
    const [edad, setedad] = useState(0)
    const [salario, setsalario] = useState(0)

// un hook para corregir el error de que no se puede ingresar texto en los inputs de edad y salario
    useEffect(() => {
        if (Number.isNaN(edad)){
            Alert.alert("Error", "No se acepta texto")
            setedad(0)
        }
        if (Number.isNaN(salario)){
            Alert.alert("Error", "No se acepta texto")
            setsalario(0)
        }
    }, [edad, salario])
    function calcular (){
        let salarioAnual;
        if (edad>=18){
            salarioAnual = salario * 12;
            Alert.alert("El salario anual es:"+ salarioAnual)
            
        }else{
            Alert.alert("Error⚠️", "El empleado tiene que ser mayor de edad")
        }
    }

  return (
    <View style={styles.container}>
        <Text style={{fontSize:40}}>Cálculo</Text>
        <TextInput
        placeholder='Ingresa nombre'
        placeholderTextColor={"#ad7767"}
        style={styles.input}
        onChangeText={(texto)=>setnombre(texto)}
        value={nombre}/>

        <TextInput
        placeholder='Ingresa edad'
        style={styles.input}
        onChangeText={(texto)=>setedad(+texto)}
        value={edad.toString()}/>
        <TextInput
        placeholder='Ingresa salario'
        style={styles.input}
        onChangeText={(texto)=>setsalario(+texto)}
        value={salario.toString()}/>
        <TouchableOpacity style={styles.btn} onPress={calcular}>
            <Text style={{fontSize:25}}>Verificar</Text>
            <Image source={{uri:"https://images.creativefabrica.com/products/previews/2024/03/18/9TbbjdEiS/2drDJiAjw7sygw5g10SGfaHk04I-mobile.jpg"}}
            style={styles.img}/>

        </TouchableOpacity>

        
      </View>
  )
}

const styles = StyleSheet.create({
    container:{
        backgroundColor:"#86ad67",
        flex:1,
        justifyContent:"center",
        alignItems:"center",
    },
    input:{
        fontSize:25,
        backgroundColor:"white",
        margin:4,
        width:"80%",
        height:50,
        borderRadius:20,
        paddingHorizontal:20,
    },
    btn:{
        backgroundColor:"#a7ad67",
        width:"90%",
        height:150,
        alignItems:"center",
        borderRadius:20,
        flexDirection:"row",
        justifyContent:"center"
        

    },
    img:{
        width:90,
        height:90,
    }
})